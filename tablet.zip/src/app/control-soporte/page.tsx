import SupportDashboard from "@/component/SupportDashboard";

const ControlSoportePage = () => {
  return <SupportDashboard apiUrl="https://sheetdb.io/api/v1/2s3i4cw7ppvtr" />;
};

export default ControlSoportePage;
