/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Stack,
  Typography,
  FormControlLabel,
  Checkbox,
  Link,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { validatePhone, formatPhone } from '@/libs/utils/formatPhone';
import { useMutation } from '@tanstack/react-query';
import { createSweepstake, setParticipantNsaRole, type NsaRole } from '@/services/sweepstake.service';
import { ThankYouModal } from './success-dialog';
import {
  printTicketWithImage,
  printTicketWithQRCodeOnly,
} from '@/libs/utils/rawBt';

interface PhoneInputModalProps {
  open: boolean;
  onClose: () => void;
  sweepstakeId: string;
  storeId?: string;
  storeName?: string;
  createdBy?: string;
  method: 'cashier' | 'tablet';
  sweepstakeName: string;
  type?: string;
  hasQR?: boolean;
  /** Aviso opcional de alta exitosa. Opcional porque los paneles ya no necesitan reaccionar. */
  onSuccessRegister?: () => void;
  userId?: string;
}

const keypad = [
  '1',
  '2',
  '3',
  '4',
  '5',
  '6',
  '7',
  '8',
  '9',
  'Delete',
  '0',
  'Send',
];

const STORAGE_KEY = 'phoneInputModal_phone';

export const PhoneInputModal: React.FC<PhoneInputModalProps> = ({
  open,
  onClose,
  sweepstakeId,
  storeId = '',
  storeName = '',
  createdBy = '',
  method,
  onSuccessRegister,
  sweepstakeName,
  type = '',
  hasQR,
  userId,
}) => {
  const [phone, setPhone] = useState('');
  const [customerName, setCustomerName] = useState('');

  const [error, setError] = useState('');
  // Arranca DESMARCADA y es deliberado. Un checkbox de consentimiento
  // pre-marcado no es consentimiento: bajo TCPA el opt-in para SMS de marketing
  // tiene que ser una acción afirmativa del titular del número. Si viene marcado
  // de fábrica nadie lo marca, y lo que queda registrado no prueba nada.
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showThanks, setShowThanks] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  // NSA (optinType === 'nsa'): el rol se pide DESPUÉS de registrar y se guarda por PATCH
  const [showNsaModal, setShowNsaModal] = useState(false);
  const [nsaParticipantId, setNsaParticipantId] = useState('');
  const isPhoneValid = validatePhone(phone);

  // Restaurar el número guardado cuando se abre el modal
  useEffect(() => {
    if (open) {
      if (typeof window !== 'undefined') {
        const savedPhone = localStorage.getItem(STORAGE_KEY);
        if (savedPhone) {
          setPhone(savedPhone);
        } else {
          setPhone('');
        }
      }
      setCustomerName('');
      setError('');
      // Cada cliente marca la suya. Heredar el consentimiento del anterior es
      // exactamente lo que hace que el registro no sirva como prueba.
      setAcceptedTerms(false);
    }
  }, [open]);

  // Guardar el número en localStorage cada vez que cambia
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (phone) {
        localStorage.setItem(STORAGE_KEY, phone);
      }
    }
  }, [phone]);

  useEffect(() => {
    if (open) {
      setAcceptedTerms(isPhoneValid);
    }
  }, [isPhoneValid, open]);

  const { mutate, isPending } = useMutation({
    mutationFn: async ({ customerName }: { customerName: string }) => {
      const resp = await createSweepstake({
        sweepstakeId,
        storeId,
        customerPhone: phone.replace(/\D/g, ''),
        customerName,
        method,
        createdBy: userId ?? createdBy,
      });
      return resp;
    },

    onSuccess: (resp) => {
      // NSA: primero se pide el rol (Owner/Manager | Seller/Brand); el ThankYou sale después.
      if (type === 'nsa') {
        setNsaParticipantId(resp?.participantId || '');
        setShowNsaModal(true);
      } else {
        setShowThanks(true);
      }

      if (type !== 'generic') {
        if (hasQR) {
          printTicketWithQRCodeOnly({
            storeName: storeName,
            phone: phone.replace(/\D/g, ''),
            couponCode: resp.coupon || 'XXXXXX',
            sweepstakeName,
            name: customerName || '',
          });
        } else {
          printTicketWithImage(
            'https://res.cloudinary.com/dg9gzic4s/image/upload/v1751982268/chiquitoy_ioyhpp.jpg',
            {
              storeName: storeName,
              phone: phone,
              couponCode: resp.coupon || 'XXXXXX',
              sweepstakeName,
            }
          );
        }
      }

      // Si quieres, aquí solo avisamos al padre de que se registró bien
      onSuccessRegister?.();

      // 👇 OJO: ya NO limpiamos ni cerramos aquí
      // Nada de onClose(), ni setPhone(''), ni setShowThanks(false) aquí
    },


    onError: (error: any) => {
      setError(error || 'An error occurred while registering.');
      setTimeout(() => {
        setError('');
      }, 5000);
    },
  });

  const handleKeyPress = (key: string) => {
    if (key === 'Delete') {
      setPhone(formatPhone(phone.slice(0, -1)));
    } else if (key === 'Send') {
      if (!acceptedTerms) {
        setError('You must accept the terms to participate.');
        return;
      }
      if (validatePhone(phone)) {
        setError('');
        if (type === 'event') {
          setShowRoleModal(true);
        } else {
          mutateWithName('');
        }
      } else {
        setError('Please enter a valid phone number');
      }
    } else {
      if (phone.replace(/\D/g, '').length < 10)
        setPhone(formatPhone(phone + key));
    }
  };

  const mutateWithName = (name: string) => {
    mutate({
      customerName: name,
    });
  };

  // NSA: guarda el rol elegido. Pase lo que pase seguimos al ThankYou —
  // en un kiosko no se bloquea al cliente si el PATCH falla (queda el log).
  const { mutate: saveNsaRole, isPending: isSavingNsaRole } = useMutation({
    mutationFn: (nsaRole: NsaRole) => setParticipantNsaRole(nsaParticipantId, nsaRole),
    onError: (err) => console.error('❌ No se pudo guardar nsaRole:', err),
    onSettled: () => {
      setShowNsaModal(false);
      setShowThanks(true);
    },
  });

  // Manejar el cierre del modal SOLO a través del botón X
  const handleCloseModal = () => {
    // Solo cerramos el modal, sin borrar el número ni el localStorage
    setError('');
    onClose();
  };

  // Prevenir cierre al hacer clic en cualquier parte del modal
  const handleModalClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={(event, reason) => {
          console.log(event, '', reason);
        }}
        BackdropProps={{
          onClick: (e) => {
            // Prevenir completamente cualquier cierre al hacer clic en el fondo
            e.preventDefault();
            e.stopPropagation();
          },
          sx: {
            // Asegurar que el backdrop no cierre el modal
            cursor: 'default',
          },
        }}
        maxWidth="sm"
        fullWidth
        disableEscapeKeyDown={true}
        sx={{
          '& .MuiPaper-root': {
            minHeight: '560px',
            background: 'transparent',
            overflow: 'hidden',
          },
          '& .MuiBackdrop-root': {
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
          },
        }}
      >
        <Box
          onClick={handleModalClick}
          sx={{
            bgcolor: '#c79b34',
            p: 3,
            borderRadius: '16px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
          }}
        >
          <Box
            onClick={handleModalClick}
            sx={{
              bgcolor: '#c79b34',
              borderRadius: '16px',
              boxShadow: 6,
            }}
          >
            <DialogTitle
              onClick={handleModalClick}
              sx={{
                color: 'white',
                textAlign: 'center',
                fontWeight: 'bold',
                fontSize: '1.1rem',
                pb: 1,
                position: 'relative',
              }}
            >
              ENTER YOUR PHONE NUMBER
              <IconButton
                onClick={(e) => {
                  e.stopPropagation();
                  handleCloseModal();
                }}
                sx={{
                  position: 'absolute',
                  right: 24,
                  top: 24,
                  color: 'white',
                  '&:hover': {
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  },
                }}
              >
                <CloseIcon />
              </IconButton>
            </DialogTitle>

            <DialogContent onClick={handleModalClick}>
              <Stack spacing={2} alignItems="center" onClick={handleModalClick}>
                <Box
                  role="textbox"
                  aria-label="Phone number"
                  aria-readonly="true"
                  sx={{
                    width: '100%',
                    minHeight: '83px',
                    px: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center',
                    fontSize: '1.8rem',
                    color: 'black',
                    backgroundColor: 'white',
                    border: '1px solid rgba(0, 0, 0, 0.23)',
                    borderRadius: 2,
                    boxSizing: 'border-box',
                  }}
                >
                  {phone}
                </Box>

                <Box
                  onClick={handleModalClick}
                  sx={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(3, 1fr)',
                    gap: 1.5,
                    width: '100%',
                  }}
                >
                  {keypad.map((key) => (
                    <Button
                      key={key}
                      variant="contained"
                      // Enviar bloqueado hasta que acepte: el error después de
                      // tocar el botón llegaba tarde y se leía como una falla.
                      // Las dos condiciones: sin número válido no hay a quién
                      // mandarle, sin consentimiento no se puede mandar.
                      disabled={key === 'Send' && (isPending || !acceptedTerms || !isPhoneValid)}
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        handleKeyPress(key);
                      }}
                      sx={{
                        backgroundColor:
                          key === 'Send'
                            ? acceptedTerms ? '#4CAF50' : '#9E9E9E'
                            : key === 'Delete'
                              ? '#E53935'
                              : 'linear-gradient(#a46c0f, #d49b34)',
                        background:
                          key === 'Send'
                            ? acceptedTerms ? '#4CAF50' : '#9E9E9E'
                            : key === 'Delete'
                              ? '#E53935'
                              : 'linear-gradient(#a46c0f, #d49b34)',
                        color: 'white',
                        fontSize: '1.4rem',
                        width: '100%',
                        height: '65px',
                        borderRadius: '6px',
                        fontWeight: 'bold',
                        boxShadow: 3,
                        '&:hover': {
                          backgroundColor:
                            key === 'Send'
                              ? '#45a049'
                              : key === 'Delete'
                                ? '#d32f2f'
                                : undefined,
                          opacity: key === 'Send' || key === 'Delete' ? 1 : 0.9,
                        },
                      }}
                    >
                      {key}
                    </Button>
                  ))}
                </Box>

                {error && (
                  <Typography
                    onClick={handleModalClick}
                    color="white"
                    fontSize="1rem"
                    sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}
                  >
                    {error}
                  </Typography>
                )}
              </Stack>
            </DialogContent>
          </Box>

          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              px: 1,
              mt: 2,
              mb: 1,
            }}
          >
            <Image
              src="/LogoPink.webp"
              alt="SweepsTouch"
              width={220}
              height={48}
              priority
              style={{
                width: '100%',
                maxWidth: '220px',
                height: 'auto',
                filter: 'brightness(0) invert(1)',
              }}
            />
          </Box>

          <FormControlLabel
            onClick={handleModalClick}
            sx={{
              mt: 1,
              alignItems: 'flex-start',
            }}
            control={
              <Checkbox
                checked={acceptedTerms}
                onChange={(e) => {
                  e.stopPropagation();
                  setAcceptedTerms(e.target.checked);
                }}
                onClick={(e) => e.stopPropagation()}
                sx={{
                  color: '#fff',
                  '&.Mui-checked': {
                    color: '#fff',
                  },
                }}
              />
            }
            label={
              <Box onClick={handleModalClick}>
                <Typography
                  color="white"
                  fontSize={'0.8rem'}
                  sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}
                >
                  By checking this box, you agree to receive recurring promotional text messages from Sweepstouch,
                  including sales, coupons, and promotional offers. Message frequency varies.
                  Message and data rates may apply. Reply STOP to opt out and HELP for help.
                  View our Terms and Conditions and Privacy Policy.
                </Typography>

                <Stack
                  direction="row"
                  spacing={1}
                  flexWrap="wrap"
                  sx={{ mt: 0.75 }}
                >
                  <Link
                    href="https://www.sweepstouch.com/term"
                    target="_blank"
                    rel="noopener noreferrer"
                    underline="always"
                    onClick={(e) => e.stopPropagation()}
                    sx={{
                      color: '#fff',
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
                    }}
                  >
                    Terms and Conditions
                  </Link>

                  <Typography
                    component="span"
                    color="white"
                    fontSize="0.8rem"
                    sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}
                  >
                    |
                  </Typography>

                  <Link
                    href="https://www.sweepstouch.com/privacy"
                    target="_blank"
                    rel="noopener noreferrer"
                    underline="always"
                    onClick={(e) => e.stopPropagation()}
                    sx={{
                      color: '#fff',
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      textShadow: '1px 1px 2px rgba(0,0,0,0.8)',
                    }}
                  >
                    Privacy Policy
                  </Link>
                </Stack>
              </Box>
            }
          />
        </Box>
      </Dialog>
      <ThankYouModal
        open={showThanks}
        onClose={() => {
          setShowThanks(false);
          setPhone('');
          setCustomerName('');
          setError('');
          if (typeof window !== 'undefined') {
            localStorage.removeItem(STORAGE_KEY);
          }
          onClose();
        }}
        isGeneric={type === 'generic'}
      />

      {/* Role Selection Modal – only for optinType 'event' */}
      <Dialog
        open={showRoleModal}
        onClose={() => { }}
        disableEscapeKeyDown
        BackdropProps={{ onClick: (e) => { e.preventDefault(); e.stopPropagation(); } }}
        maxWidth="xs"
        fullWidth
        sx={{ '& .MuiPaper-root': { background: 'transparent', overflow: 'hidden' } }}
      >
        <Box
          sx={{
            bgcolor: '#c79b34',
            p: 4,
            borderRadius: '16px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            textAlign: 'center',
          }}
        >
          <Typography
            variant="h6"
            fontWeight="bold"
            color="white"
            mb={3}
            sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}
          >
            ARE YOU AN OWNER OR EMPLOYEE?
          </Typography>
          <Stack spacing={2}>
            <Button
              variant="contained"
              fullWidth
              onClick={() => {
                setShowRoleModal(false);
                mutateWithName('Owner');
              }}
              sx={{
                background: 'linear-gradient(#a46c0f, #d49b34)',
                color: 'white',
                fontSize: '1.1rem',
                fontWeight: 'bold',
                height: '60px',
                borderRadius: '8px',
                boxShadow: 3,
                '&:hover': { opacity: 0.9 },
              }}
            >
              OWNER
            </Button>
            <Button
              variant="contained"
              fullWidth
              onClick={() => {
                setShowRoleModal(false);
                mutateWithName('Employee');
              }}
              sx={{
                background: 'linear-gradient(#1565c0, #1e88e5)',
                color: 'white',
                fontSize: '1.1rem',
                fontWeight: 'bold',
                height: '60px',
                borderRadius: '8px',
                boxShadow: 3,
                '&:hover': { opacity: 0.9 },
              }}
            >
              EMPLOYEE
            </Button>
          </Stack>
        </Box>
      </Dialog>

      {/* NSA Role Modal – solo para optinType 'nsa'. Sale DESPUÉS de registrar el número. */}
      <Dialog
        open={showNsaModal}
        onClose={() => { }}
        disableEscapeKeyDown
        BackdropProps={{ onClick: (e) => { e.preventDefault(); e.stopPropagation(); } }}
        maxWidth="xs"
        fullWidth
        sx={{ '& .MuiPaper-root': { background: 'transparent', overflow: 'hidden' } }}
      >
        <Box
          sx={{
            bgcolor: '#c79b34',
            p: 4,
            borderRadius: '16px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            textAlign: 'center',
          }}
        >
          <Typography
            variant="h6"
            fontWeight="bold"
            color="white"
            mb={3}
            sx={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}
          >
            WHICH ONE ARE YOU?
          </Typography>
          <Stack spacing={2}>
            {(
              [
                { label: 'OWNER / MANAGER', role: 'owner_manager' },
                { label: 'SELLER / BRAND', role: 'seller_brand' },
              ] as { label: string; role: NsaRole }[]
            ).map(({ label, role }) => (
              <Button
                key={role}
                variant="contained"
                fullWidth
                disabled={isSavingNsaRole}
                onClick={() => saveNsaRole(role)}
                sx={{
                  background: 'linear-gradient(#a46c0f, #d49b34)',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: 'bold',
                  height: '60px',
                  borderRadius: '8px',
                  boxShadow: 3,
                  '&:hover': { opacity: 0.9 },
                  '&.Mui-disabled': { background: 'linear-gradient(#a46c0f, #d49b34)', opacity: 0.6, color: 'white' },
                }}
              >
                {label}
              </Button>
            ))}
          </Stack>
        </Box>
      </Dialog>

    </>
  );
};
