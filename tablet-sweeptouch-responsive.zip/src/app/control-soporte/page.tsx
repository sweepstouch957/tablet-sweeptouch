
import ControlSoporte from "@/component/controlContainer";

const ControlSoportePage = () => {

  return (
        <ControlSoporte/>
  );
};

export default ControlSoportePage;
